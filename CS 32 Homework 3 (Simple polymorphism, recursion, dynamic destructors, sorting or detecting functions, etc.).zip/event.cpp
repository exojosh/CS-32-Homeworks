class Event
{
public:
    Event(const string& s);
    virtual ~Event()=0 {}
    string name() const;
    virtual bool isSport() const;
    virtual string need() const = 0;
private:
    string m_name;
};

bool Event::isSport() const
{
    return 1;
}

Event::Event(const string& s)
{
    m_name = s;
}

string Event::name() const
{
    return m_name;
}


class Concert: public Event
{
public:
    Concert(const string& nam, const string& gen);
    virtual bool isSport() const;
    virtual string need() const;
    ~Concert();
private:
    string genre;
};

bool Concert::isSport() const
{
    return 0;
}

string Concert::need() const
{
    return "a stage";
}

Concert::Concert(const string& nam, const string& gen) : Event(nam)
{
    genre = gen;
}

Concert::~Concert()
{
    cout << "Destroying the " << this->name() << " " << this->genre << " concert\n";
}


class BasketballGame: public Event
{
public:
    BasketballGame(const string& s);
    ~BasketballGame();
    virtual string need() const;
private:
};

BasketballGame::BasketballGame(const string& s) : Event(s)
{

}
string BasketballGame::need() const
{
    return "hoops";
}


BasketballGame::~BasketballGame()
{
    cout << "Destroying the " << this->name() << " basketball game\n";
}


class HockeyGame: public Event
{
public:
    HockeyGame(const string& s);
    ~HockeyGame();
    virtual string need() const;
private:
};

HockeyGame::HockeyGame(const string& s) : Event(s)
{

}

string HockeyGame::need() const
{
    return "ice";
}

HockeyGame::~HockeyGame()
{
    cout << "Destroying the " << this->name() << " hockey game\n";
}
