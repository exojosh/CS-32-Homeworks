bool anyFalse(const double a[], int n)
{
	if (!somePredicate(a[n - 1]))
		return true;
	else if (n-1 != 0)
		return anyFalse(a, n - 1);
	return false;
}

int countTrue(const double a[], int n)
{
	if (n >= 1)
	{
		if (somePredicate(a[n - 1]))
			return countTrue(a, n - 1) + 1;
		else
			return countTrue(a, n - 1);
	}
	else return 0;
}

int firstTrue(const double a[], int n)
{
	int x = 0;
	if (n <= 0)
		return -1;
	if (n != 0)
	{
		x = firstTrue(a, n - 1);
		if (x != -1)
			return x;
		else if (somePredicate(a[n - 1]))
			return n - 1;
		else return -1;
	}
}
int positionOfSmallest(const double a[], int n)
{
	int x = 0;
	if (n < 1)
		return -1;
	if (n == 1)
		return 0;
	if (n != 0)
	{
		x = positionOfSmallest(a, n - 1);
		if (a[x] <= a[n - 1])
			return x;
		else return n - 1;
	}
}

bool contains(const double a1[], int n1, const double a2[], int n2)
{
	if (n1 == n2 && n1 == 1)
	{
		if (a1[0] == a2[0])
			return true;
		else
			return false;
	}
	if (n2 < 1)
		return true;
	if (n1 <= 1)
		return false;
	if (a1[n1 - 1] == a2[n2 - 1])
		return contains(a1, n1 - 1, a2, n2 - 1);
	else return contains(a1, n1 - 1, a2, n2);
}