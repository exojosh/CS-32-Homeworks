#include <queue>
#include <iostream>
using namespace std;

class Coord
{
public:
    Coord(int rr, int cc) : m_r(rr), m_c(cc) {}
    int r() const { return m_r; }
    int c() const { return m_c; }
private:
    int m_r;
    int m_c;
};

bool pathExists(string maze[], int nRows, int nCols, int sr, int sc, int er, int ec)
{
    queue<Coord> coordStack;
    coordStack.push(Coord(sr, sc));
    int x = sr, y = sc;
    while (!coordStack.empty())
    {
        x = coordStack.front().r(); y = coordStack.front().c();
        coordStack.pop();
        if (x == er && y == ec)
        {
            return true;
        }
        if (maze[x][y + 1] != 'X')
        {
            coordStack.push(Coord(x, y + 1));
            maze[x][y + 1] = 'X';
        }
        if (maze[x + 1][y] != 'X')
        {
            coordStack.push(Coord(x + 1, y));
            maze[x + 1][y] = 'X';
        }
        if (maze[x][y - 1] != 'X')
        {
            coordStack.push(Coord(x, y - 1));
            maze[x][y - 1] = 'X';
        }
        if (maze[x - 1][y] != 'X')
        {
            coordStack.push(Coord(x - 1, y));
            maze[x - 1][y] = 'X';
        }
    }
    return false;
}