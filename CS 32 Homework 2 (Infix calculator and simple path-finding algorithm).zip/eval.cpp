#include "Map.h"
#include <string>
#include <stack>
using namespace std;

bool checkSyntax(const string& s);
bool checkValues(const string& s, const Map& m);
void convert(const string& infix,  string& postfix);
int switchCase(const char& ch);
bool solve(string& postfix, int& result, const Map& m);

int evaluate(string infix, const Map& values, string& postfix, int& result)
{
	if (!checkSyntax(infix))
		return 1;
	convert(infix, postfix);
	if (!checkValues(infix, values))
		return 2;
	if (!solve(postfix, result, values))
		return 3;
	return 0;
}

bool checkSyntax(const string& s)
{
	char last = 0;
	int p = 0;
	if (s == "")
		return false;
	else if (s[0] == 42 || s[0] == 43 || s[0] == 45 || s[0] == 47)
		return false;
	for (int i = 0; i < s.length(); i++)
	{
		if (s[i] == 32) //Ignore spaces
			continue;
		else if (!((s[i] <= 43 && s[i] >= 40) || s[i] == 45 || s[i] == 47 || (s[i] >= 97 && s[i] <= 122))) //Tests if char is a space, parentheses, operand, or operator
			return false;
		else if (s[i] == 41 && s[i - 1] == 40)
			return false;
		else if ((s[i] == 42 || s[i] == 43 || s[i] == 45 || s[i] == 47) && (last == 42 || last == 43 || last == 45 || last == 47 || last == 40))
			return false;
		else if ((s[i] >= 97 && s[i] <= 122) && (last >= 97 && last <= 122))
			return false;
		else if (s[i] == 40 && (last >= 97 && last <= 122))
			return false;
		last = s[i];

		if (s[i] == 40)
			p++;
		else if (s[i] == 41)
			p--;
	}
	if (last == 42 || last == 43 || last == 45 || last == 47 || last == 40 || p != 0)
		return false;
	else
	return true;
}

bool checkValues(const string& s, const Map& m)
{
	KeyType temp;
	for (int i = 0; i < s.length(); i++)
	{
		if ((s[i] >= 97 && s[i] <= 122))
		{
			temp = s[i];
			if (!m.contains(temp))
				return false;
		}
	}
	return true;
}

void convert(const string& infix, string& postfix)
{
	postfix = "";
	stack<char> oper;
	for (int i = 0; i < infix.length(); i++)
	{
		int k = switchCase(infix[i]);
		switch (k)
		{
		case 1:
			postfix = postfix + infix[i];
			break;
		case 2:
			oper.push(infix[i]);
			break;
		case 3:
			while (oper.top() != 40)
			{
				postfix = postfix + oper.top();
				oper.pop();
			}
			oper.pop();
			break;
		case 4:
			while (!oper.empty() && oper.top() != 40 && !((infix[i] == 42 || infix[i] == 47) && (oper.top() == 43 || oper.top() == 45)))
			{
				postfix = postfix + oper.top();
				oper.pop();
			}
			oper.push(infix[i]);
			break;
		}
	}
	while (!oper.empty())
	{
		postfix = postfix + oper.top();
		oper.pop();
	}
}

int switchCase(const char& ch)
{
	if (ch >= 97 && ch <= 122) //operand
		return 1;
	else if (ch == 40) // (
		return 2;
	else if (ch == 41) // )
		return 3;
	else if (ch == 42 || ch == 43 || ch == 45 || ch == 47) // operator
		return 4;
	else if (ch == 32) // space
		return 5;
	else return -1; //Should never happen
}

bool solve(string& postfix, int& result, const Map& m)
{
	stack<int> oper;
	KeyType s;
	ValueType i1 = 0, i2 = 0, i3 = 0;
	for (int i = 0; i < postfix.length(); i++)
	{ 
		s = postfix[i];
		if (postfix[i] >= 97 && postfix[i] <= 122)
		{
			m.get(s, i1);
			oper.push(i1);
		}
		else {
			i2 = oper.top();
			oper.pop();
			i1 = oper.top();
			oper.pop();
			if (postfix[i] == 42)
				i3 = i1 * i2;
			else if (postfix[i] == 43)
				i3 = i1 + i2;
			else if (postfix[i] == 45)
				i3 = i1 - i2;
			else if (postfix[i] == 47)
			{
				if (i2 == 0)
					return false;
				else
					i3 = i1 / i2;
			}
			oper.push(i3);
		}
	}
		result = oper.top();
		oper.pop();
	return true;
}
