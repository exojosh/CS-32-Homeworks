#ifndef CARMAP_H
#define CARMAP_H
#include "Map.h"


class CarMap
{
private:
    Map c_map;

public:
    CarMap();

    bool addCar(KeyType license);

    ValueType miles(KeyType license) const;

    bool drive(KeyType license, ValueType distance);

    int fleetSize() const;

    void print() const;
 

};
#endif