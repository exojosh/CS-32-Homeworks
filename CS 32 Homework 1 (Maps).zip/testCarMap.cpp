#include "CarMap.h"
#include <cassert>
#include <iostream>

int main()
{
	CarMap garage;
	garage.addCar("4HYU849");
	garage.addCar("1HUA012");
	assert(garage.fleetSize() == 2);
	assert(garage.miles("lol") == -1);
	garage.addCar("1HUA012");
	assert(garage.fleetSize() == 2);
	garage.addCar("2DNK45E");
	garage.drive("2DNK45E", 20);
	garage.drive("2DNK45E", 17);
	assert(garage.fleetSize() == 3 && garage.miles("2DNK45E") == 37);
	garage.print();

	std::cout << "Passed all tests, baby!" << std::endl;


}