#include "CarMap.h"
#include <iostream>

    CarMap::CarMap() {}     // Create an empty car map.

    bool CarMap::addCar(KeyType license)
    {
        return c_map.insert(license, 0);
    }

    ValueType CarMap::miles(KeyType license) const 
    {
        ValueType x;
        if (c_map.contains(license))
        {
            c_map.get(license, x); return x;
        }
        else return -1;
    }

    bool CarMap::drive(KeyType license, ValueType distance) 
    {
        ValueType y;
        if (!c_map.contains(license) || distance < 0) return false;
        c_map.get(license, y);
        c_map.update(license, y + distance);
        return true;
    }

    int CarMap::fleetSize() const 
    {
        return c_map.size();
    }

    void CarMap::print() const 
    {
        KeyType a;
        ValueType b;
        for (int i = 0; i < fleetSize(); i++)
        {
            c_map.get(i, a, b);
            std::cout << a << " " << b << "\n";
        }
    }