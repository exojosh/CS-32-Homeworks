#include "Map.h"
#include <iostream>
#include <cassert>
using namespace std;

int main()
{
    Map m, n;  // maps strings to doubles
    assert(m.empty());
    ValueType v = -1234.5;
    assert(!m.get("abc", v) && v == -1234.5); // v unchanged by get failure
    m.insert("xyz", 9876.5);
    assert(m.size() == 1);
    KeyType k = "hello";
    assert(m.get(0, k, v) && k == "xyz" && v == 9876.5);
    assert(m.contains("xyz") && !m.contains("jkl"));
    assert(m.insertOrUpdate("abc", 3));
    m.insertOrUpdate("iop", 2.714);
    m.get("abc", v);
    assert(m.contains("iop") && v == 3);
    m.update("xyz", 2.212);
    m.get(0, k, v);
    assert(v == 2.212);
    assert(m.erase("xyz"));
    n.swap(m);
    assert(m.empty() && n.size() == 2);

    cout << "Passed all tests" << endl;
}