#include "Map.h"

    Map::Map()
    {
    }


    bool Map::empty() const
    {

        if (this->size() == 0) return true;
        else return false;
    }
    int Map::size() const
    {
        return m_size;
    }

    bool Map::insert(const KeyType& key, const ValueType& value)
    {
        if (this->size() >= DEFAULT_MAX_ITEMS)
            return false;
        ptr = mymap;
        for(int i = 0; i < this->size(); i++)
        {
            if (key == ptr->key) return false;
            ptr++;
        }
        mymap[size()].key = key; //As soon as this key is assigned, the size iterates by one so we must assign the value to "size()-1"
        mymap[size()].value = value;
        m_size++;
        return true;
    }

    bool Map::update(const KeyType& key, const ValueType& value)
    {
        ptr = mymap;
        for (int i = 0; i < this->DEFAULT_MAX_ITEMS; i++)
        {
            if (key == ptr->key) 
            {
                ptr->value = value; 
                return true;
            }
            ptr++;
        }
        return false;
    }

    bool Map::insertOrUpdate(const KeyType& key, const ValueType& value)
    {
        ptr = mymap;
        for (int i = 0; i < this->size(); i++)
        {
            if (key == ptr->key)
            {
                ptr->value = value;
                return true;
            }
            ptr++;
        }
        if (this->size() >= DEFAULT_MAX_ITEMS) return false;
        ptr = mymap;
        mymap[size()].key = key;
        mymap[size()].value = value;
        m_size++;
        return true;
    }

    bool Map::erase(const KeyType& key)
    {
        ptr = mymap;
        KeyPair dummy;
        for (int i = 0; i < this->size(); i++)
        {
            if (key == ptr->key)
            {
                for (int k = 0; k < this->size(); k++)
                {
                    mymap[k] = mymap[k + 1];
                }
                mymap[size()] = dummy; 
                m_size--;
                return true;//Necessary in case the element with the matching key is the last element since it would try to otherwise copy from a nonexistant object.
            }
            ptr++;
        }
        return false;
    }

        bool Map::contains(const KeyType & key) const
    {
            for (int i = 0; i < this->size(); i++)
            {
                if (key == mymap[i].key)
                {
                    return true;
                }
            }
            return false;
    }

    bool Map::get(const KeyType& key, ValueType& value) const
    {
            for (int i = 0; i < DEFAULT_MAX_ITEMS; i++)
            {
                if (key == mymap[i].key)
                {
                    value = mymap[i].value;
                    return true;
                }
            }
            return false;
    }

    bool Map::get(int i, KeyType& key, ValueType& value) const
    {
        if ( i >= 0 && i < size())
        {
            value = mymap[i].value;
            key = mymap[i].key;
            return true;
        }
       return false;
    }

    void Map::swap(Map& other)
        {
        ValueType v;
        KeyType k;
        int s;
        for (int i = 0; i < DEFAULT_MAX_ITEMS; i++)
            {
            k = this->mymap[i].key;
            v = this->mymap[i].value;
            this->mymap[i].key = other.mymap[i].key;
            this->mymap[i].value = other.mymap[i].value;
            other.mymap[i].key = k;
            other.mymap[i].value = v;
            }
        s = this->m_size;
        this->m_size = other.m_size;
        other.m_size = s;
        }