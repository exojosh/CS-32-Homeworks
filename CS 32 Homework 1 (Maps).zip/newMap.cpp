#include "newMap.h"

Map::Map()
{
    mymap = new struct KeyPair[DEFAULT_MAX_ITEMS];
    ptr = mymap;
    MAX_ITEMS = DEFAULT_MAX_ITEMS;
}

Map::Map(int pairs)
{
    if (pairs < 0) exit;
    mymap = new struct KeyPair[pairs];
    ptr = mymap;
    MAX_ITEMS = pairs;
}

Map::Map(const Map& other)
{
    this->mymap = other.mymap;
    this->ptr = other.ptr;
    this->m_size = other.m_size;
    this->MAX_ITEMS = other.MAX_ITEMS;
}

bool Map::empty() const
{

    if (this->size() == 0) return true;
    else return false;
}
int Map::size() const
{
    return m_size;
}

bool Map::insert(const KeyType& key, const ValueType& value)
{
    if (this->size() >= MAX_ITEMS)
        return false;
    ptr = mymap;
    for (int i = 0; i < this->size(); i++)
    {
        if (key == ptr->key) return false;
        ptr++;
    }
    mymap[size()].key = key; //As soon as this key is assigned, the size iterates by one so we must assign the value to "size()-1"
    mymap[size()].value = value;
    m_size++;
    return true;
}

bool Map::update(const KeyType& key, const ValueType& value)
{
    ptr = mymap;
    for (int i = 0; i < this->MAX_ITEMS; i++)
    {
        if (key == ptr->key)
        {
            ptr->value = value;
            return true;
        }
        ptr++;
    }
    return false;
}

bool Map::insertOrUpdate(const KeyType& key, const ValueType& value)
{
    ptr = mymap;
    for (int i = 0; i < this->size(); i++)
    {
        if (key == ptr->key)
        {
            ptr->value = value;
            return true;
        }
        ptr++;
    }
    if (this->size() >= MAX_ITEMS) return false;
    ptr = mymap;
    mymap[size()].key = key;
    mymap[size()].value = value;
    m_size++;
    return true;
}

bool Map::erase(const KeyType& key)
{
    ptr = mymap;
    KeyPair dummy;
    for (int i = 0; i < this->size(); i++)
    {
        if (key == ptr->key)
        {
            for (int k = 0; k < this->size(); k++)
            {
                mymap[k] = mymap[k + 1];
            }
            mymap[size()] = dummy;
            m_size--;
            return true;//Necessary in case the element with the matching key is the last element since it would try to otherwise copy from a nonexistant object.
        }
        ptr++;
    }
    return false;
}

bool Map::contains(const KeyType& key) const
{
    for (int i = 0; i < this->size(); i++)
    {
        if (key == mymap[i].key)
        {
            return true;
        }
    }
    return false;
}

bool Map::get(const KeyType& key, ValueType& value) const
{
    for (int i = 0; i < MAX_ITEMS; i++)
    {
        if (key == mymap[i].key)
        {
            value = mymap[i].value;
            return true;
        }
    }
    return false;
}

bool Map::get(int i, KeyType& key, ValueType& value) const
{
    if (i >= 0 && i < size())
    {
        value = mymap[i].value;
        key = mymap[i].key;
        return true;
    }
    return false;
}

void Map::swap(Map& other)
{
    int s;
    struct KeyPair* dummy;
    dummy = this->mymap;
    this->mymap = other.mymap;
    other.mymap = dummy;    
    s = this->m_size;
    this->m_size = other.m_size;
    other.m_size = s;
    s = this->MAX_ITEMS;
    this->MAX_ITEMS = other.MAX_ITEMS;

}